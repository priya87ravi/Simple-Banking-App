﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Models.EFEntities
{
    public class Payee
    {
        public int PayeeId { get; set; }
        public string CustomerId { get; set; }
        [Required]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }
        [Required]
        [Display(Name = "Account Number")]
        public string AccountNumber { get; set; }
        [Required]
        [Display(Name = "Bank Code")]
        public string BankCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        [Display(Name = "Last updated on")]
        public DateTime AddedOn { get; set; }
    }
}
