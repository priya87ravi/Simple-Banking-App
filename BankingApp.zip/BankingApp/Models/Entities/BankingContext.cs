﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankingApp.Models;
using Microsoft.AspNetCore.Identity;
using BankingApp.Models.EFEntities;

namespace BankingApp.Models.EFEntities
{
    public class BankingContext: IdentityDbContext<Customer>
    {
        public BankingContext(DbContextOptions<BankingContext> options) : base(options)
        { }

        public BankingContext()
        {
        }
        public DbSet<Account> accounts { get; set; }
        public DbSet<Payee> payees { get; set; }
        public DbSet<PaymentHistory> paymentHistories { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("name=BOC");
            }
        }
        public DbSet<BankingApp.Models.AccountActivity> AccountActivity { get; set; }
    }
}
