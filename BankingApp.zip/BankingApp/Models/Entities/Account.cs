﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Models.EFEntities
{
    public class Account
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public float Balance { get; set; }


        [Display(Name = "Account No.")]
        public string AccountNo { get; set; }

        public bool IsTeller { get; set; }
    }
}
