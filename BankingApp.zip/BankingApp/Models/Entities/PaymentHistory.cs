﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Models.EFEntities
{
    public class PaymentHistory
    {
        public int Id { get; set; }
        public string CustomerId { get; set; }
        public int PayeeId { get; set; }
        public float Amount { get; set; }
        public DateTime ActionDate { get; set; }
    }
}
