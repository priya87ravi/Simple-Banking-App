﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Models
{
    public class TellerTransactionsView
    {
        public int Id { get; set; }
        [Display(Name = "First name")]
        public string FirstName { get; set; }
        [Display(Name = "Last name")]
        public string LastName { get; set; }
        [Display(Name = "Email Address")]
        public string EmailAddress { get; set; }
        [Display(Name = "Phone Number")]
        public string Phone { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        [Display(Name = "Date of Birth")] 
        public DateTime DOB { get; set; }
        [Display(Name = "Current Balance")]
        public float CurrentBalance { get; set; }
        public float CreditDebitAmount { get; set; }
    }
    public class Payments
    {
        public int Id { get; set; }
        public string CustomerId { get; set; }
        public int PayeeId { get; set; }
        public string PayeeName { get; set; }
        public float Amount { get; set; }
        public DateTime TransactionDate { get; set; }

        public string CustomerName { get; }
    }

    public class AccountActivity
    {
        public int Id { get; set; }

        [Display(Name = "Account No.")]
        public string AccountNo { get; set; }

        [Display(Name = "Email")]
        public string CustomerId { get; set; }

        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }
        public float Amount { get; set; }

        [Display(Name = "Date")]
        public DateTime TransactionDate { get; set; }

        [Display(Name = "Withdrawal / Deposit")]
        public string ActivityType { get; set; }
    }
}
