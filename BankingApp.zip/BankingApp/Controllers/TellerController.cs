﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BankingApp.Models;
using BankingApp.Models.EFEntities;
using BankingApp.Data.IDataAccess;

namespace BankingApp.Controllers
{
    public class TellerController : Controller
    {

        private readonly UserManager<Customer> userManager;

        private ITellerDataAccess _tellerDataAccess;
        private IAccountsDataAccess _accountsDataAccess;
        private ICustomersDataAccess _customersDataAccess;
        public TellerController(UserManager<Customer> userManager, ITellerDataAccess tda, IAccountsDataAccess ada,
            ICustomersDataAccess cda)
        {
            this.userManager = userManager;
            _tellerDataAccess = tda;
            _accountsDataAccess = ada;
            _customersDataAccess = cda;

        }
        public IActionResult Index()
        {
            return View();
        }
        
        public IActionResult CustomerDetails()
        {
            var accounts = _customersDataAccess.GetAllCustomers();
            List<Customer> bankCustomers = new List<Customer>();
            
               foreach (var user in userManager.Users)
                {
                
                if (user.UserName != "admin@gmail.com")
                {
                    if (User.Identity.Name == "admin@gmail.com")
                    {
                        bankCustomers.Add(user);
                    }
                    else
                    {
                        foreach (var account in accounts)
                        {
                            if (!account.IsTeller && account.UserName == user.UserName)
                            {
                                bankCustomers.Add(user);
                            }
                        }
                    }
                }
                    
                }
            
            return View(bankCustomers);
        }
        public async Task<IActionResult> DeleteUser(string id)
        {
            var user = userManager.FindByIdAsync(id).Result;
            _accountsDataAccess.DeleteUser(user.UserName);
            var result  = await userManager.DeleteAsync(user);
            if (!result.Succeeded)
            {
                ModelState.AddModelError(string.Empty, "Invalid username or password entered.");
                return View();
            }

            return RedirectToAction("CustomerDetails");
        }

        public IActionResult EditUser(string id)
        {
            var user = userManager.Users.Where(x => x.Id.Equals(id)).FirstOrDefault();
            return RedirectToAction("CustomerProfileView","CustomerProfile",user);
        }
        public IActionResult Withdraw(string id)
        {
            var user = userManager.Users.Where(x => x.Id.Equals(id)).FirstOrDefault();
            var cust = _accountsDataAccess.GetAccount(user.UserName);
            var customerList = new TellerTransactionsView
            {
                
                FirstName = user.FirstName,
                LastName = user.LastName,
                City = user.City,
                State = user.State,
                EmailAddress = user.UserName,
                Phone = user.PhoneNumber,
                DOB = user.DOB,
                CurrentBalance = cust.Balance
            };
            TempData["WOrD"] = "Withdraw";
            return View("TellerTransactions", customerList);
        }
        public IActionResult Deposit(string id)
        {
            var user = userManager.Users.Where(x => x.Id.Equals(id)).FirstOrDefault();
            var cust = _accountsDataAccess.GetAccount(user.UserName);
            TempData["WOrD"] = "Deposit";
            return View("TellerTransactions", new TellerTransactionsView
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                City = user.City,
                State = user.State,
                EmailAddress = user.UserName,
                Phone = user.PhoneNumber,
                DOB = user.DOB,
                CurrentBalance = cust.Balance
            });
        }
        public IActionResult TellerTransactions(TellerTransactionsView model, string Debit, string Credit, string Cancel)
        {
            var customer = _accountsDataAccess.GetAccount(model.EmailAddress);
            var user = userManager.Users.Where(x => x.UserName.Equals(customer.UserName)).FirstOrDefault();
            if (Request.Method == "POST")
            {
                if (Debit != null)
                {
                    if (model.CreditDebitAmount > customer.Balance)
                    {
                        ModelState.AddModelError(string.Empty, "Customer " + customer.UserName + " does not have sufficient balance to make this transaction.");
                        return View("TellerTransactions");
                    }
                    else
                    {
                        customer.Balance = customer.Balance - model.CreditDebitAmount;
                        _accountsDataAccess.UpdateAccount(customer);
                        
                        _tellerDataAccess.CreateAccountActivity(new AccountActivity
                        {
                            ActivityType = "Withdrawal",
                            Amount = model.CreditDebitAmount,
                            CustomerId = user.UserName,
                            CustomerName = user.FirstName + " " + user.LastName,
                            TransactionDate = DateTime.Now,
                            AccountNo = _accountsDataAccess.GetAccount(customer.UserName).AccountNo
                        });
                        return RedirectToAction("CustomerDetails");
                    }
                }
                if (Credit != null)
                {
                    customer.Balance = customer.Balance + model.CreditDebitAmount;
                    _accountsDataAccess.UpdateAccount(customer);
                    _tellerDataAccess.CreateAccountActivity(new AccountActivity
                    {
                        ActivityType = "Deposit",
                        Amount = model.CreditDebitAmount,
                        CustomerId = user.UserName,
                        CustomerName = user.FirstName + " " + user.LastName,
                        TransactionDate = DateTime.Now,
                        AccountNo = _accountsDataAccess.GetAccount(customer.UserName).AccountNo
                    });
                    return RedirectToAction("CustomerDetails");
                }
                if (Cancel != null)
                {
                    return RedirectToAction("CustomerDetails");
                }
            }
            return View();
        }
        public IActionResult TransactionsListForCustomer(DateTime FromDate, DateTime ToDate, string SortBy)
        {
            
            ViewBag.SortName = string.IsNullOrEmpty(SortBy) ? "desc" : "";
            var transactions = _tellerDataAccess.GetAllAccountActivitiesForCustomer(User.Identity.Name, FromDate, ToDate);
            if (SortBy == "desc")
                transactions.OrderByDescending(x => x.TransactionDate);
            else
                transactions.OrderBy(x => x.TransactionDate);
            return View("TransactionsList", transactions);
        }
        public IActionResult TransactionsList(DateTime FromDate, DateTime ToDate, string SortBy)
        {
            ViewBag.SortName = string.IsNullOrEmpty(SortBy) ? "desc" : "";
            var transactions = _tellerDataAccess.GetAllAccountActivities(FromDate, ToDate);
            if (SortBy == "desc")
                transactions= transactions.OrderByDescending(x => x.TransactionDate).ToList();
            else
                transactions= transactions.OrderBy(x => x.TransactionDate).ToList();
            return View(transactions);
        }

    }
}
