﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using BankingApp.Models;
using BankingApp.Models.EFEntities;
using BankingApp.Data.IDataAccess;

namespace BankingApp.Controllers
{
    public class UserController : Controller
    {
        private IAccountsDataAccess _accountsDataAccess;


        public UserController(UserManager<Customer> userManager, SignInManager<Customer> siginManager,
           IAccountsDataAccess ada )
        {
            _userManager = userManager;
            _signInManager = siginManager;
            _accountsDataAccess = ada;
        }

        public UserManager<Customer> _userManager { get; }
        public SignInManager<Customer> _signInManager { get; }
        public async Task<IActionResult> Login(Login model)
        {
            if (!(string.IsNullOrEmpty(model.Email) && string.IsNullOrEmpty(model.Password)))
            {
                if (ModelState.IsValid)
                {
                    var user =_userManager.Users.FirstOrDefault(x => x.Email == model.Email);
                    if(user == null)
                    {
                        ModelState.AddModelError(string.Empty, "Invalid username or password entered.");
                        return View();
                    }
                    var result = await _signInManager.CheckPasswordSignInAsync(user, model.Password, false);
                    if (result.Succeeded)
                    {
                        await _signInManager.SignInAsync(user,model.RememberMe);
                        
                        return RedirectToAction("Index", "Home");

                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Invalid username or password entered.");
                        return View();
                    }
                }
            }
            return View();
        }

       
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(Registration model)
        {
            if (Request.Method == "POST")
            {
                String startWith = "32";
                Random generator = new Random();
                String r = generator.Next(0, 999999).ToString("D6");
                String aAccounNumber = startWith + r;
                if (ModelState.IsValid)
                {
                    var user = new Customer
                    {
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        UserName = model.Email,
                        Email = model.Email,
                        PhoneNumber = model.Phone,
                        City = model.City,
                        State = model.State,
                        EmailConfirmed = true,
                        Gender = model.Gender,
                        DOB = model.DOB,
                        AccountNo = aAccounNumber,
                        IsTeller = model.IsTeller ? true: false
                    };
                    var result = await _userManager.CreateAsync(user, model.Pwd);
                    if (result.Succeeded)
                    {
                        var account = new Account
                        {
                            UserName = model.Email,
                            IsTeller = model.IsTeller ? true : false,
                            AccountNo = aAccounNumber
                            //,Balance = 0
                        };
                        _accountsDataAccess.AddAccount(account);
                        var response = await _userManager.AddToRoleAsync(user, model.IsTeller ? "teller" : "customer");
                        if (response.Succeeded)
                        {
                            return RedirectToAction("Index", "Home");
                        }
                        foreach (var error in response.Errors)
                        {
                            ModelState.AddModelError("", error.Description);
                        }
                    }
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            return View();
        }
    }
}
