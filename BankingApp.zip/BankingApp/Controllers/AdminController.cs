﻿using BankingApp.Models.EFEntities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Controllers
{
    public class AdminController
    {
        private BankingContext _context;

        public AdminController(BankingContext context, UserManager<Customer> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        public UserManager<Customer> _userManager { get; }
        public void CreateAdminUser()
        {
            var user = new Customer
            {
                FirstName = "Admin",
                UserName = "admin@gmail.com",
                NormalizedEmail = "ADMIN@GMAIL.COM",
                Email = "admin@gmail.com",
                NormalizedUserName = "ADMIN@GMAIL.COM",
                EmailConfirmed = true,
                City = "Washington",
                SecurityStamp = Guid.NewGuid().ToString()
            };


            var roleStore = new RoleStore<IdentityRole>(_context);

            if (!(_context.Roles.Any()))
            {
                roleStore.CreateAsync(new IdentityRole { Name = "bankadmin", NormalizedName = "BANKADMIN" });
                roleStore.CreateAsync(new IdentityRole { Name = "teller", NormalizedName = "TELLER" });
                roleStore.CreateAsync(new IdentityRole { Name = "customer", NormalizedName = "CUSTOMER" });
            }

            if (!_context.Users.Any(u => u.UserName == user.UserName))
            {
                var userStore = new UserStore<Customer>(_context);
                _userManager.CreateAsync(user, "Admin@123");
                userStore.AddToRoleAsync(user, "bankadmin");
            }
            _context.SaveChangesAsync();


        }
    }
}
