﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using BankingApp.Models.EFEntities;
using BankingApp.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Rendering;
using BankingApp.Data.IDataAccess;

namespace BankingApp.Controllers
{
    public class PaymentsController : Controller
    {
        
        private readonly UserManager<Customer> userManager;

        private IPaymentsDataAccess _paymentsDataAccess;
        private IAccountsDataAccess _accountsDataAccess;

            public PaymentsController(UserManager<Customer> userManager, IPaymentsDataAccess pda, IAccountsDataAccess ada)
        {
            this.userManager = userManager;
            _paymentsDataAccess = pda;
            _accountsDataAccess = ada;
        }
        public IActionResult PayeeList()
        {
            return View(_paymentsDataAccess.GetPayees(User.Identity.Name));
        }
        public IActionResult Edit(int id)
        {
            
            return View("ManagePayee", _paymentsDataAccess.GetPayeeById(id));
        }
        public IActionResult Details(int id)
        {
            return View(_paymentsDataAccess.GetPayeeById(id));
        }
        public IActionResult Delete(int id)
        {
            _paymentsDataAccess.DeletePayee(id);
            return RedirectToAction("PayeeList");
        }
        public IActionResult ManagePayee(Payee payee, string save, string edit)
        {
            if (Request.Method == "POST")
            {
                payee.AddedOn = DateTime.Now;
                payee.CustomerId = User.Identity.Name;
                
                if (save != null)
                    _paymentsDataAccess.AddPayees(payee);
                else if (edit != null)
                    _paymentsDataAccess.UpdatePayee(payee);
                
                return RedirectToAction("PayeeList");
            }
            return View();
        }

        public IActionResult Transact(int[] PayeeId, string next, string cancel)
        {
            if (Request.Method == "POST")
            {
                if (next != null)
                {
                    List<Payments> phList = new List<Payments>();
                    foreach(int id in PayeeId)
                    {
                        phList.Add(new Payments { Amount = 0, CustomerId = User.Identity.Name, PayeeId = id, PayeeName = _paymentsDataAccess.GetPayeeById(id).FullName,TransactionDate = System.DateTime.Now});
                    }
                    TempData["phList"] = JsonConvert.SerializeObject(phList);
                    return View("TransactAmount", phList);
                }
                if (cancel != null)
                {
                    return RedirectToAction("Transact");
                }
            }
            ViewBag.PayeeId = new SelectList(_paymentsDataAccess.GetPayees(User.Identity.Name), "PayeeId", "FullName");
            return View();
        }

       
        public IActionResult TransactAmount(IList<Payments> model)
        {
            if (Request.Method == "POST")
            {
                float sum = 0;
                foreach (var payeeDetail in model)
                {
                    PaymentHistory hist = new PaymentHistory {CustomerId = User.Identity.Name,ActionDate = DateTime.Now,
                        PayeeId = payeeDetail.PayeeId,
                        Amount = payeeDetail.Amount
                    };
                    _paymentsDataAccess.CreatePaymentHistory(hist);
                    sum += payeeDetail.Amount;
                }
                var UserModel = _accountsDataAccess.GetAccount(User.Identity.Name);
                if (sum > UserModel.Balance)
                {
                    ModelState.AddModelError(string.Empty, "Insufficient Funds!");
                    ViewBag.PayeeId = new SelectList(_paymentsDataAccess.GetPayees(User.Identity.Name)
                                    , "PayeeId", "FullName");
                    List<Payments> phList = JsonConvert.DeserializeObject<List<Payments>>(Convert.ToString(TempData["phList"]));
                    return View(phList);
                }
                else
                {
                    UserModel.Balance = UserModel.Balance - sum;
                    _accountsDataAccess.UpdateAccount(UserModel);
                    return RedirectToAction("PaymentHistory");
                }
            }
            return View();
        }

        public IActionResult PaymentHistory(DateTime FromDate, DateTime ToDate, string SortBy)
        {
            ViewBag.SortName = string.IsNullOrEmpty(SortBy) ? "desc" : "";
            List<Payments> payments = new List<Payments>();
            if (Request.Method == "POST")
            {
                payments = _paymentsDataAccess.GetAllPayments(User.Identity.Name, FromDate, ToDate);
            }
            else
            {
                payments = _paymentsDataAccess.GetAllPaymentsForCustomer(User.Identity.Name);
            }
            if (SortBy == "desc")
                payments=payments.OrderByDescending(x => x.TransactionDate).ToList();
            else
                payments=payments.OrderBy(x => x.TransactionDate).ToList();
            return View(payments);
        }
        public IActionResult CompletePaymentHistory(DateTime FromDate, DateTime ToDate)
        {
            List<Payments> payments = new List<Payments>();
            payments = _paymentsDataAccess.GetAllPayments(FromDate, ToDate);
            return View("PaymentHistory",payments);
        }
    }
}
