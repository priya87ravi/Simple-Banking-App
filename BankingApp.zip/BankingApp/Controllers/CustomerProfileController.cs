﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using BankingApp.Models;
using BankingApp.Models.EFEntities;
using BankingApp.Data.IDataAccess;

namespace BankingApp.Controllers
{
    public class CustomerProfileController : Controller
    {
        
        private readonly UserManager<Customer> userManager;

        private IAccountsDataAccess _accountsDataAccess;
        public CustomerProfileController(UserManager<Customer> userManager, IAccountsDataAccess ada)
        {
            this.userManager = userManager;
            _accountsDataAccess = ada;
        }
        public IActionResult Index()
        {
            if (User.Identity.Name == "admin@gmail.com")
            {
                return RedirectToAction("CustomerDetails", "Teller");
            }
            else
            {
                ViewBag.Balance = _accountsDataAccess.GetAccount(User.Identity.Name).Balance;
                return View();
            }
            
        }

        public IActionResult CustomerProfileView(Customer user)
        {
            var u=userManager.FindByEmailAsync(user.UserName);

            var model = new Customer
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                DOB = user.DOB,
                City = user.City,
                Email = user.Email,
                Gender = user.Gender,
                PhoneNumber = user.PhoneNumber,
                State = user.State,
                AccountNo = user.AccountNo

            };
            return View("MyProfile",model);
        }


        [HttpGet]
        public async Task<IActionResult> MyProfile()
        {
            var user = await userManager.FindByEmailAsync(User.Identity.Name);
            var account = _accountsDataAccess.GetAccount(User.Identity.Name);
                var model = new Customer
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    DOB = user.DOB,
                    City = user.City,
                    Email = user.Email,
                    Gender = user.Gender,
                    PhoneNumber = user.PhoneNumber,
                    State = user.State,
                    AccountNo = account.AccountNo

                };
                return View(model);
            

        }



        [HttpPost]
        public async Task<IActionResult> MyProfile(Customer customer, string edit, string cancel)
        {
            var user = await userManager.FindByEmailAsync(customer.UserName);
            var account = _accountsDataAccess.GetAccount(customer.UserName);
            if(edit!= null)
            {
                user.FirstName = customer.FirstName;
                user.LastName = customer.LastName;
                user.DOB = customer.DOB;
                user.City = customer.City;
                user.State = customer.State;
                user.PhoneNumber = customer.PhoneNumber;
                user.Gender = customer.Gender;
                var result = await userManager.UpdateAsync(user);
                if(!result.Succeeded)
                {
                    ModelState.AddModelError(string.Empty, "Invalid username or password entered.");
                    return View();
                }
            }
            return RedirectToAction("Index");
        }
    }
}
