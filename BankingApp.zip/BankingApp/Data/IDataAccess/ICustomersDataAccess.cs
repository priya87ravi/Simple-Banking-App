﻿using BankingApp.Models.EFEntities;
using System.Collections.Generic;

namespace BankingApp.Data.IDataAccess
{
    public interface ICustomersDataAccess
    {
        List<Account> GetAllCustomers();
    }
}