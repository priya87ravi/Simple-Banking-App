﻿using BankingApp.Models;
using BankingApp.Models.EFEntities;
using System;
using System.Collections.Generic;

namespace BankingApp.Data.IDataAccess
{
    public interface IPaymentsDataAccess
    {
        void AddPayees(Payee payee);

        void UpdatePayee(Payee payee);

        void DeletePayee(int payeeId);

        List<Payee> GetPayees(string userName);
        Payee GetPayeeById(int id);

        void CreatePaymentHistory(PaymentHistory history);

        List<Payments> GetAllPayments(string Uname, DateTime FromDate, DateTime ToDate);
        List<Payments> GetAllPayments(DateTime FromDate, DateTime ToDate);
        List<Payments> GetAllPaymentsForCustomer(string Uname);


    }
}