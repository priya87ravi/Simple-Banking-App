﻿using BankingApp.Models.EFEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Data.IDataAccess
{
    public interface IAccountsDataAccess
    {
        void AddAccount(Account account);

        void UpdateAccount(Account Account);

        void DeleteAccount(int AccountId);

        Account GetAccount(string userName);

        void DeleteUser(string Id);
    }
}
