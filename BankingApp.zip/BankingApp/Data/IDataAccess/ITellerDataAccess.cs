﻿using BankingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Data.IDataAccess
{
    public interface ITellerDataAccess
    {
        void CreateAccountActivity(AccountActivity accountActivity);

        List<AccountActivity> GetAllAccountActivities(DateTime FromDate, DateTime ToDate);

        List<AccountActivity> GetAllAccountActivities();

        List<AccountActivity> GetAllAccountActivitiesForCustomer(string uname, DateTime FromDate, DateTime ToDate);
    }
}
