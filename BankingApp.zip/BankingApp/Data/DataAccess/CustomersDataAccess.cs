﻿using BankingApp.Data.IDataAccess;
using BankingApp.Models.EFEntities;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Data.DataAccess
{
    public class CustomersDataAccess : ICustomersDataAccess
    {

        private BankingContext context { get; set; }

        public CustomersDataAccess( BankingContext ctx)
        {
            context = ctx;
        }
        

        public List<Account> GetAllCustomers()
        {
           return context.accounts.Where(x=>!x.IsTeller).ToList();
        }
    }
}
