﻿using BankingApp.Data.IDataAccess;
using BankingApp.Models;
using BankingApp.Models.EFEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Data.DataAccess
{
    public class PaymentsDataAccess : IPaymentsDataAccess
    {
        private BankingContext context { get; set; }

        public PaymentsDataAccess(BankingContext ctx)
        {
            context = ctx;
        }
        public void AddPayees(Payee payee)
        {
            context.payees.Add(payee);
            context.SaveChanges();
        }

        public void DeletePayee(int payeeId)
        {
            Payee payee = new Payee();
            payee = context.payees.Find(payeeId);
            context.payees.Remove(payee);
            context.SaveChanges();
        }

        public void UpdatePayee(Payee payee)
        {
            context.payees.Update(payee);
            context.SaveChanges();
        }

        public List<Payee> GetPayees(string userName)
        {
            return context.payees.Where(x=>x.CustomerId == userName).ToList();
        }

        public Payee GetPayeeById(int id)
        {
            return context.payees.Find(id);
        }

        public void CreatePaymentHistory(PaymentHistory history)
        {
            context.paymentHistories.Add(history);
        }

        public List<Payments> GetAllPayments(string Uname, DateTime FromDate, DateTime ToDate)
        {
            List<Payments> payments = new List<Payments>();
            var history = from ph in context.paymentHistories
                          join pa in context.payees on ph.PayeeId equals pa.PayeeId
                          where ph.CustomerId.Equals(Uname) && ph.ActionDate >= FromDate && ph.ActionDate <= ToDate
                          select new
                          {
                              ph.Id,
                              ph.CustomerId,
                              ph.Amount,
                              ph.ActionDate,
                              pa.FullName
                          };
            foreach (var h in history)
                payments.Add(new Payments {Id = h.Id, CustomerId = h.CustomerId, PayeeName = h.FullName, Amount = h.Amount, TransactionDate = h.ActionDate });

            return payments;
        }
        public List<Payments> GetAllPayments(DateTime FromDate, DateTime ToDate)
        {
            List<Payments> payments = new List<Payments>();
            var history = from ph in context.paymentHistories
                          join pa in context.payees on ph.PayeeId equals pa.PayeeId
                          select new
                          {
                              ph.Id,
                              ph.CustomerId,
                              ph.Amount,
                              ph.ActionDate,
                              pa.FullName
                          };

            if (FromDate != DateTime.MinValue && ToDate != DateTime.MinValue)
                history = history.Where(x => x.ActionDate >= FromDate && x.ActionDate <= ToDate);
            foreach (var h in history)
                payments.Add(new Payments { Id = h.Id, CustomerId = h.CustomerId, PayeeName = h.FullName, Amount = h.Amount, TransactionDate = h.ActionDate });

            return payments;
        }
        public List<Payments> GetAllPaymentsForCustomer(string Uname)
        {
            List<Payments> payments = new List<Payments>();
            var history = from ph in context.paymentHistories
                          join pa in context.payees on ph.PayeeId equals pa.PayeeId
                          where ph.CustomerId.Equals(Uname) 
                          select new
                          {
                              ph.Id,
                              ph.CustomerId,
                              ph.Amount,
                              ph.ActionDate,
                              pa.FullName
                          };
            foreach (var h in history)
                payments.Add(new Payments { Id = h.Id, CustomerId = h.CustomerId, PayeeName = h.FullName, Amount = h.Amount, TransactionDate = h.ActionDate });

            return payments;
        }
    }
}
