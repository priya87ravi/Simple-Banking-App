﻿using BankingApp.Data.IDataAccess;
using BankingApp.Models.EFEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Data.DataAccess
{
    public class AccountsDataAccess : IAccountsDataAccess
    {

        private BankingContext context { get; set; }

        public AccountsDataAccess(BankingContext ctx)
        {
            context = ctx;
        }
        public void AddAccount(Account account)
        {
            context.accounts.Add(account);
            context.SaveChanges();
        }

        public void DeleteAccount(int AccountId)
        {
            Account account = new Account();
            account = context.accounts.Find(AccountId);
            context.accounts.Remove(account);
            context.SaveChanges();
        }

        public Account GetAccount(string id)
        {
            return context.accounts.Where(x=>x.UserName== id).FirstOrDefault();
        }


        public void UpdateAccount(Account Account)
        {
            context.accounts.Update(Account);
            context.SaveChanges();
        }

        public void DeleteUser(string Id)
        {
            var phList = context.paymentHistories.Where(x => x.CustomerId == Id).ToList();
            context.paymentHistories.RemoveRange(phList);

            var accountActivities = context.AccountActivity.Where(x => x.CustomerId == Id).ToList();
            context.AccountActivity.RemoveRange(accountActivities);

            var payees = context.payees.Where(x => x.CustomerId == Id).ToList();
            context.payees.RemoveRange(payees);

            var accounts = context.accounts.Where(x => x.UserName == Id).ToList();
            context.accounts.RemoveRange(accounts);
            context.SaveChanges();
        }
    }
}
