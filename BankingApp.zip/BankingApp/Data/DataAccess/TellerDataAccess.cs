﻿using BankingApp.Data.IDataAccess;
using BankingApp.Models;
using BankingApp.Models.EFEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Data.DataAccess
{
    public class TellerDataAccess : ITellerDataAccess
    {
        private BankingContext context { get; set; }

        public TellerDataAccess(BankingContext ctx)
        {
            context = ctx;
        }
        public void CreateAccountActivity(AccountActivity accountActivity)
        {
            context.AccountActivity.Add(accountActivity);
            context.SaveChanges();
        }

        public List<AccountActivity> GetAllAccountActivities(DateTime FromDate, DateTime ToDate)
        {
            if (FromDate != DateTime.MinValue && ToDate != DateTime.MinValue)
                return context.AccountActivity.Where(x => x.TransactionDate >= FromDate && x.TransactionDate <= ToDate).ToList();
            else
                return context.AccountActivity.ToList();
        }

        public List<AccountActivity> GetAllAccountActivities()
        {
            return context.AccountActivity.ToList();
        }

        public List<AccountActivity> GetAllAccountActivitiesForCustomer(string uname, DateTime FromDate, DateTime ToDate)
        {
            if (FromDate != DateTime.MinValue && ToDate != DateTime.MinValue)
                return context.AccountActivity.Where(x => x.CustomerId == uname && x.TransactionDate >= FromDate && x.TransactionDate <= ToDate).ToList();
            else
                return context.AccountActivity.Where(x => x.CustomerId == uname).ToList();
        }
    }
}
