﻿using System;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace BankingApp.Models.EFEntities
{
    public partial class NetBankingContext : IdentityDbContext<Customer>
    {
        public NetBankingContext()
        {
        }

        public NetBankingContext(DbContextOptions<NetBankingContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Account> Account { get; set; }
        public virtual DbSet<AccountActivity> AccountActivity { get; set; }
        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<Payee> Payee { get; set; }
        public virtual DbSet<PaymentHistory> PaymentHistory { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.\\SQLExpress;Database=NetBanking;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Account>(entity =>
            //{
            //    entity.Property(e => e.Id)
            //        .HasColumnName("ID")
            //        .ValueGeneratedNever();

            //    entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

            //    entity.HasOne(d => d.Customer)
            //        .WithMany(p => p.Account)
            //        .HasForeignKey(d => d.CustomerId)
            //        .HasConstraintName("FK__Account__Custome__267ABA7A");
            //});

            //modelBuilder.Entity<AccountActivity>(entity =>
            //{
            //    entity.Property(e => e.Id)
            //        .HasColumnName("ID")
            //        .ValueGeneratedNever();

            //    entity.Property(e => e.AccountId).HasColumnName("AccountID");

            //    entity.Property(e => e.CreatedDt).HasColumnType("datetime");

            //    entity.HasOne(d => d.Account)
            //        .WithMany(p => p.AccountActivity)
            //        .HasForeignKey(d => d.AccountId)
            //        .HasConstraintName("FK__AccountAc__Accou__29572725");
            //});

            //modelBuilder.Entity<Customer>(entity =>
            //{
            //    entity.Property(e => e.Id)
            //        .HasColumnName("ID")
            //        .ValueGeneratedNever();

            //    entity.Property(e => e.AddressLine1)
            //        .HasMaxLength(500)
            //        .IsUnicode(false);

            //    entity.Property(e => e.City)
            //        .HasMaxLength(100)
            //        .IsUnicode(false);

            //    entity.Property(e => e.FirstName)
            //        .HasMaxLength(250)
            //        .IsUnicode(false);

            //    entity.Property(e => e.LastName)
            //        .HasMaxLength(250)
            //        .IsUnicode(false);

            //    entity.Property(e => e.Password)
            //        .HasMaxLength(100)
            //        .IsUnicode(false);

            //    entity.Property(e => e.StateName)
            //        .HasMaxLength(100)
            //        .IsUnicode(false);

            //    entity.Property(e => e.UserName)
            //        .HasMaxLength(100)
            //        .IsUnicode(false);
            //});

            //modelBuilder.Entity<Payee>(entity =>
            //{
            //    entity.Property(e => e.Id)
            //        .HasColumnName("ID")
            //        .ValueGeneratedNever();

            //    entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

            //    entity.Property(e => e.PayeeName)
            //        .HasMaxLength(250)
            //        .IsUnicode(false);

            //    entity.HasOne(d => d.Customer)
            //        .WithMany(p => p.Payee)
            //        .HasForeignKey(d => d.CustomerId)
            //        .HasConstraintName("FK__Payee__CustomerI__2C3393D0");
            //});

            //modelBuilder.Entity<PaymentHistory>(entity =>
            //{
            //    entity.Property(e => e.Id)
            //        .HasColumnName("ID")
            //        .ValueGeneratedNever();

            //    entity.Property(e => e.AccountId).HasColumnName("AccountID");

            //    entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

            //    entity.Property(e => e.PayeeId).HasColumnName("PayeeID");

            //    entity.Property(e => e.PaymentDate).HasColumnType("datetime");

            //    entity.HasOne(d => d.Account)
            //        .WithMany(p => p.PaymentHistory)
            //        .HasForeignKey(d => d.AccountId)
            //        .HasConstraintName("FK__PaymentHi__Accou__300424B4");

            //    entity.HasOne(d => d.Customer)
            //        .WithMany(p => p.PaymentHistory)
            //        .HasForeignKey(d => d.CustomerId)
            //        .HasConstraintName("FK__PaymentHi__Custo__2F10007B");

            //    entity.HasOne(d => d.Payee)
            //        .WithMany(p => p.PaymentHistory)
            //        .HasForeignKey(d => d.PayeeId)
            //        .HasConstraintName("FK__PaymentHi__Payee__30F848ED");
            //});

            //OnModelCreatingPartial(modelBuilder);
            base.OnModelCreating(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
