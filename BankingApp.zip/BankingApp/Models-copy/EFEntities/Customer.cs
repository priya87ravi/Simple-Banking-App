﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace BankingApp.Models.EFEntities
{
    public class Customer : IdentityUser
    {
        public Customer()
        {
            Account = new HashSet<Account>();
            Payee = new HashSet<Payee>();
            PaymentHistory = new HashSet<PaymentHistory>();
        }

        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool? IsTeller { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AddressLine1 { get; set; }
        public string City { get; set; }
        public string StateName { get; set; }
        public int? PinCode { get; set; }

        public string SecurityStamp { get; set; }
        public virtual ICollection<Account> Account { get; set; }
        public virtual ICollection<Payee> Payee { get; set; }
        public virtual ICollection<PaymentHistory> PaymentHistory { get; set; }
    }
}
