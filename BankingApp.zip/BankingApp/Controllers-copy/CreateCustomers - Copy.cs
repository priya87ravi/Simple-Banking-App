﻿using BankingApp.Models.EFEntities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApp.Controllers
{
    public class CreateCustomers
    {
        private NetBankingContext _context;

        public CreateCustomers(NetBankingContext context, UserManager<Customer> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        public UserManager<Customer> _userManager { get; }
        public void InsertDefaultUser()
        {
            //var user = new Customer
            //{
            //    FirstName = "Banker",
            //    UserName = "admin@gmail.com",
            //    NormalizedUserName = "ADMIN@GMAIL.COM",
            //    Email = "admin@gmail.com",
            //    NormalizedEmail = "ADMIN@GMAIL.COM",
            //    EmailConfirmed = true,
            //    LockoutEnabled = false,
            //    PhoneNumber = "8903232342",
            //    City = "Washington",
            //    SecurityStamp = Guid.NewGuid().ToString()
            //};
            var user = new Customer
            {
                FirstName = "Teller",
                UserName = "admin@gmail.com",
                NormalizedEmail = "ADMIN@GMAIL.COM",
                NormalizedUserName = "ADMIN@GMAIL.COM",
                IsTeller = true,
                City = "Washington",
                SecurityStamp = Guid.NewGuid().ToString()
            };

            var roleStore = new RoleStore<IdentityRole>(_context);

            if (!(_context.Roles.Any()))
            {
                roleStore.CreateAsync(new IdentityRole { Name = "teller", NormalizedName = "TELLER" });
                roleStore.CreateAsync(new IdentityRole { Name = "customer", NormalizedName = "CUSTOMER" });
            }

            if (!_context.Users.Any(u => u.UserName == user.UserName))
            {
                var userStore = new UserStore<Customer>(_context);
                var result = _userManager.CreateAsync(user, "Admin@123");
                userStore.AddToRoleAsync(user, "teller");
            }
            _context.SaveChangesAsync();


        }
    }
}
